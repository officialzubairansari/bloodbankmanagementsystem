﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace Blood_Management_Sytem
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True");
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[usersdata]([fullname],[dob],[sex],[contacno],[address] ,[email],[password])VALUES('" + textBox1.Text + "', '" + textBox3.Text + "', '" + comboBox1.SelectedItem.ToString() + "','" + textBox6.Text + "', '" + textBox8.Text + "', '" + textBox7.Text + "', '" + textBox5.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            panel1.Visible = true;



        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            home frm3 = new home();
            frm3.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
                
                panel1.Visible = false;
      
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            this.Close();
            home frm3 = new home();
            frm3.Show();
            
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void signup_Load(object sender, EventArgs e)
        {

        }
    }
}
