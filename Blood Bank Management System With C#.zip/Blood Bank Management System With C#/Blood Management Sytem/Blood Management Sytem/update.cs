﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Blood_Management_Sytem
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True"))
            {



                SqlCommand cmdupdate = new SqlCommand("Update donorsdata SET [Full Name] = '" + textBox1.Text + "',[Date of Birth] =  '" + textBox3.Text + "' ,[Gender] =  '" + comboBox2.SelectedItem.ToString() + "' ,[Blood Group] =  '" + comboBox1.SelectedItem.ToString() + "' ,[Disease] =  '" + textBox8.Text + "' ,[Address] =  '" + textBox7.Text + "',[CNIC No] =  '" + textBox6.Text + "',[Contact No] =  '" + textBox4.Text + "' ,[Email] =  '" + textBox2.Text + "' ,[Password] =  '" + textBox5.Text + "' where [Donor ID]=" + textBox9.Text + "", con);
                con.Open();
                cmdupdate.CommandType = CommandType.Text;
                cmdupdate.ExecuteNonQuery();
                panel1.Visible = true;
                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void update_Load(object sender, EventArgs e)
        {

        }
    }
}
