﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Blood_Management_Sytem
{
    public partial class delete : Form
    {
        public delete()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
           
            using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True"))
                {
               
                string str = "DELETE FROM donorsdata WHERE [Donor ID] = '" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(str, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    panel1.Visible = true;


            }
          
        }




        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            
            this.Close();



        }
    }
}
