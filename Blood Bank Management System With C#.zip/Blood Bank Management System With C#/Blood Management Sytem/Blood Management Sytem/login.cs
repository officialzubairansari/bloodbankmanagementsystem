﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Blood_Management_Sytem
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True");
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from usersdata where email = '" + textBox1.Text + "' and password = '" + textBox2.Text + "'", cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            int count = 0;
            while (dr.Read())
            {
                count += 1;
            }
            if (count == 1)
            {
               
                dashboardarea f4 = new dashboardarea();
                f4.Show();
                this.Hide();
            }
           
            else
            {
                panel1.Visible = true;
               
                

            }
            textBox1.Clear();
            textBox2.Clear();
        }

    private void button2_Click(object sender, EventArgs e)
        {
            home frm1 = new home();
            frm1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            home frm1 = new home();
            frm1.Show();
            this.Hide();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}
