﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Blood_Management_Sytem
{
    public partial class add : Form
    {
        public add()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True");
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[donorsdata]
           ([Full Name]
           ,[Date of Birth]
           ,[Gender]
           ,[Blood Group]
           ,[Disease]
           ,[Address]
           ,[CNIC No]
           ,[Contact No]
           ,[Email]
           ,[Password])VALUES('" + textBox1.Text + "', '" + textBox3.Text + "', '" + comboBox2.SelectedItem.ToString() + "', '" + comboBox1.SelectedItem.ToString() + "','" + textBox8.Text + "', '" + textBox7.Text + "', '" + textBox6.Text + "', '" + textBox4.Text + "', '" + textBox2.Text + "', '" + textBox5.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            panel1.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void add_Load(object sender, EventArgs e)
        {

        }
    }
}
