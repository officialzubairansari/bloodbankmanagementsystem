﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace Blood_Management_Sytem
{
    public partial class dashboardarea : Form
    {
        public dashboardarea()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-91O9A02\SQL2014;Initial Catalog=DB_BBMS;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM donorsdata",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            home frm3 = new home();
            frm3.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           


        }

        private void button4_Click(object sender, EventArgs e)
        {
            update frm3 = new update();
            frm3.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            delete frm3 = new delete();
            frm3.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            email frm3 = new email();
            frm3.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
           
            dataGridView1.Visible = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            add frm3 = new add();
            frm3.ShowDialog();
            
        }
    }
}
